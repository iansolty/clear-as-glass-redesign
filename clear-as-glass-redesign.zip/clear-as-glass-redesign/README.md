# Clear As Glass — Premium Website Redesign

A six-page responsive Next.js website for Clear As Glass in Morgantown, WV.

## Run locally

Install Node.js 20+, run `npm install`, then `npm run dev`. Open http://localhost:3000.

## Deployment

Push this folder to a GitHub repository, import it in Vercel as a Next.js project, and deploy to a temporary preview domain. Only connect clearasglass.info after owner approval and full QA.

## Form setup (required before launch)

The contact form has server-side required-field validation, email format validation, and a honeypot field. It intentionally returns an error until delivery is configured. Sign up for Resend, verify a domain and set `RESEND_API_KEY` and `CONTACT_FROM_EMAIL` in the Vercel environment. Ensure the sender domain is verified and test a submission end to end. Add rate limiting and CAPTCHA before public launch for robust abuse protection.

## Content and images

Current service descriptions and short testimonial excerpts are derived from the public Clear As Glass website. The photo treatments are **illustrative Unsplash architecture photography**, NOT actual project photos. Replace with approved images from the original site before client handoff. The gallery links to the original gallery rather than inventing before-and-after comparisons.

## Owner verification checklist

- Confirm operating days/hours (existing pages conflict).
- Confirm Morgantown address and email ending in `.stl`.
- Confirm both phone numbers.
- Confirm free estimates before using “Get a Free Quote.”
- Confirm 35+ years, insured status, and full service list.
- Confirm approval to reproduce testimonials and use original work photos.
- Test contact email delivery, mobile layouts, navigation, image loading, metadata, accessibility and performance.
- Verify domain ownership and DNS before cutover; preserve old site until new launch approved.

## Scope

Includes Home, Services, Gallery, Reviews, About, Contact, SEO metadata, robots.txt, sitemap, responsive layout, mobile menu, click-to-call and mailto links. Not yet production-ready until above steps are completed.
