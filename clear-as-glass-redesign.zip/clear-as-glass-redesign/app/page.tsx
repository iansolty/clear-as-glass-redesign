import Site from './Client';export default function Home(){return <Site/>}
